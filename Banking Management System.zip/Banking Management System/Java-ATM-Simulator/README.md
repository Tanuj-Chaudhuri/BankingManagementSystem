# Banking Management System
This is a Bank's ATM built in java with swing.

To run, click on the "ATM" application 

or

Compile src and run Welcome.java