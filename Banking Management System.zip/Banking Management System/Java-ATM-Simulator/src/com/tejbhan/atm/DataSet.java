
package com.tejbhan.atm;

public class DataSet {

    public static double balance = 10000;
    public static double lastTransaction = 0;
    public static String transaction = "";
}
